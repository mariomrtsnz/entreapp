package visiton.erasmus.visiton.retrofit.generator;

public enum AuthType {
    NO_AUTH, BASIC, JWT
}
